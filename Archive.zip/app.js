var images = document.querySelectorAll('img');
for (var i = 0; i < images.length; i++)
{
	images[i].src = 'https://media1.giphy.com/media/2aKCnMYAkaAS5AvQQ2/giphy.gif?cid=3640f6095c6e888d4433647a3214f3ec'
}
